%% r: caculate the distance between a and b
function [dista] = r(a, b, c, d)
    dista = sqrt((a - c)^2 + (b - d)^2);